from fastapi import FastAPI, Request
import requests

app = FastAPI()
ES_URL = "http://es:9200/india/_search"

@app.post("/query")
async def query_es(request: Request):
    data = await request.json()
    res = requests.post(ES_URL, json={
        "query": {
            "match": {
                "text": data["query"]
            }
        }
    })
    return res.json()

@app.post("/insert")
async def insert_doc(request: Request):
    data = await request.json()
    res = requests.post("http://es:9200/india/_doc", json=data)
    return res.json()
