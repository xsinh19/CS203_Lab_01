from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
import requests

app = FastAPI()
BACKEND_URL = "http://10.128.0.2:9567"

@app.get("/", response_class=HTMLResponse)
def home():
    return """
    <html>
        <body>
            <h2>ElasticSearch Query</h2>
            <form action="/get" method="post">
                <input name="query" type="text">
                <button type="submit">Get</button>
            </form>
            <form action="/insert" method="post">
                <textarea name="text"></textarea>
                <button type="submit">Insert</button>
            </form>
        </body>
    </html>
    """

@app.post("/get")
async def get_doc(request: Request):
    form = await request.form()
    res = requests.post(f"{BACKEND_URL}/query", json={"query": form['query']})
    return res.json()

@app.post("/insert")
async def insert_doc(request: Request):
    form = await request.form()
    res = requests.post(f"{BACKEND_URL}/insert", json={"text": form['text']})
    return res.json()
